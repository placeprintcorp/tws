' Copyright (C) 2021 Interactive Brokers LLC. All rights reserved. This code is subject to the terms
' and conditions of the IB API Non-Commercial License or the IB API Commercial License, as applicable.

Imports IBApi

Class UserInfoEventArgs
    Property reqId As Integer
    Property whiteBrandingId As String

End Class
