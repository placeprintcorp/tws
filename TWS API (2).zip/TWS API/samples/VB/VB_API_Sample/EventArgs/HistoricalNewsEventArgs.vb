﻿' Copyright (C) 2019 Interactive Brokers LLC. All rights reserved. This code is subject to the terms
' and conditions of the IB API Non-Commercial License or the IB API Commercial License, as applicable.

Class HistoricalNewsEventArgs

    Property requestId As Integer

    Property time As String

    Property providerCode As String

    Property articleId As String

    Property headline As String

End Class

